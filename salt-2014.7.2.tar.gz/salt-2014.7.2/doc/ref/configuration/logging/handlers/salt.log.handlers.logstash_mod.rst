.. automodule:: salt.log.handlers.logstash_mod
