=================
salt.runners.jobs
=================

.. automodule:: salt.runners.jobs
    :members: