=================
salt.runners.virt
=================

.. automodule:: salt.runners.virt
    :members: