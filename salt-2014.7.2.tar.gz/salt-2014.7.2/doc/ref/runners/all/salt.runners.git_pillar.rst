=======================
salt.runners.git_pillar
=======================

.. automodule:: salt.runners.git_pillar
    :members: