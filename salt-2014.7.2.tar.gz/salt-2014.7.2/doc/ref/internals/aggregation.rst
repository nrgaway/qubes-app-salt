================
salt.serializers
================

.. automodule:: salt.utils.aggregation
    :members:
