===================
salt.returners.odbc
===================

.. automodule:: salt.returners.odbc
    :members: