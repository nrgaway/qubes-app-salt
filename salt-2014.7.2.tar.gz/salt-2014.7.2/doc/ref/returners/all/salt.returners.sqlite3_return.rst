=======================
salt.returners.sqlite3
=======================

.. automodule:: salt.returners.sqlite3_return
    :members:
