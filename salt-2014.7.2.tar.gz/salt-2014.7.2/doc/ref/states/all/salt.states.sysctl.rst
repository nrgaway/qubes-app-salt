==================
salt.states.sysctl
==================

.. automodule:: salt.states.sysctl
    :members: