===========================
salt.states.rabbitmq_policy
===========================

.. automodule:: salt.states.rabbitmq_policy
    :members: