===============
salt.states.gem
===============

.. automodule:: salt.states.gem
    :members: