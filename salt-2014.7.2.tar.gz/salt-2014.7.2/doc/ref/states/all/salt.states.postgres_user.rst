=========================
salt.states.postgres_user
=========================

.. automodule:: salt.states.postgres_user
    :members: