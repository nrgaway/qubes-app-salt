===================
salt.states.aws_sqs
===================

.. automodule:: salt.states.aws_sqs
    :members:
