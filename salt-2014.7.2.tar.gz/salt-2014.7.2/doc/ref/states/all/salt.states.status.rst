==================
salt.states.status
==================

.. automodule:: salt.states.status
    :members: