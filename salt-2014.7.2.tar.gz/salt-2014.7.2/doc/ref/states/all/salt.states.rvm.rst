===============
salt.states.rvm
===============

.. automodule:: salt.states.rvm
    :members: