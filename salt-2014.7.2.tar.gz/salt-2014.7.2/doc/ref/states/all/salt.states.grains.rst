==================
salt.states.grains
==================

.. automodule:: salt.states.grains
    :members: