===============
salt.states.apt
===============

.. automodule:: salt.states.apt
    :members:
