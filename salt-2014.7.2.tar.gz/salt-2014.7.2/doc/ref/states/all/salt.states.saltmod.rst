===================
salt.states.saltmod
===================

.. automodule:: salt.states.saltmod
    :members: