========================
salt.states.gnomedesktop
========================

.. automodule:: salt.states.gnomedesktop
    :members: