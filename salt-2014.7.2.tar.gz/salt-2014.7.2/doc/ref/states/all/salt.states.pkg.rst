===============
salt.states.pkg
===============

.. automodule:: salt.states.pkg
    :members: