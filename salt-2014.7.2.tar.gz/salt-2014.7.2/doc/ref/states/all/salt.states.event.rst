=================
salt.states.event
=================

.. automodule:: salt.states.event
    :members:
    :exclude-members: fire_master, mod_watch
