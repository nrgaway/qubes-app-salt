====================
salt.states.nftables
====================

.. automodule:: salt.states.nftables
    :members: