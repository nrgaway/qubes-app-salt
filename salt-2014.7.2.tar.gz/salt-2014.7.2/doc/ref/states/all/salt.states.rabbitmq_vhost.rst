==========================
salt.states.rabbitmq_vhost
==========================

.. automodule:: salt.states.rabbitmq_vhost
    :members: