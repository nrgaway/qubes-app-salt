=========================
salt.states.rabbitmq_user
=========================

.. automodule:: salt.states.rabbitmq_user
    :members: