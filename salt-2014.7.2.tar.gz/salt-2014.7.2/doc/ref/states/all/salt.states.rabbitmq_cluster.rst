============================
salt.states.rabbitmq_cluster
============================

.. automodule:: salt.states.rabbitmq_cluster
    :members: