============================
salt.states.mongodb_database
============================

.. automodule:: salt.states.mongodb_database
    :members: