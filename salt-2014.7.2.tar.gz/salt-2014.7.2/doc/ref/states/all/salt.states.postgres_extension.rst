==============================
salt.states.postgres_extension
==============================

.. automodule:: salt.states.postgres_extension
    :members:
