===========================
salt.states.rabbitmq_plugin
===========================

.. automodule:: salt.states.rabbitmq_plugin
    :members: