==========================
salt.states.portage_config
==========================

.. automodule:: salt.states.portage_config
    :members: