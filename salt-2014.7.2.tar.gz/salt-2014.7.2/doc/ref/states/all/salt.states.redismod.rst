====================
salt.states.redismod
====================

.. automodule:: salt.states.redismod
    :members:
