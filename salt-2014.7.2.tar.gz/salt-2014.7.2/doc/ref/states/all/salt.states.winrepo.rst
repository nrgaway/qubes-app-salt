===================
salt.states.winrepo
===================

.. automodule:: salt.states.winrepo
    :members: