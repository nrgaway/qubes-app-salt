====================
salt.states.boto_asg
====================

.. automodule:: salt.states.boto_asg
    :members: