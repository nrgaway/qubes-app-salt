=================================
salt.states.boto_cloudwatch_alarm
=================================

.. automodule:: salt.states.boto_cloudwatch_alarm
    :members: