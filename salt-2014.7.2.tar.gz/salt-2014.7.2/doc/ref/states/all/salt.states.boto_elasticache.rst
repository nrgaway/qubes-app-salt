============================
salt.states.boto_elasticache
============================

.. automodule:: salt.states.boto_elasticache
    :members: