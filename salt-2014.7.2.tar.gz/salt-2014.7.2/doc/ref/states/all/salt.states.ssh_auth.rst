====================
salt.states.ssh_auth
====================

.. automodule:: salt.states.ssh_auth
    :members: