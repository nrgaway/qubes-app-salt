================
salt.states.smtp
================

.. automodule:: salt.states.smtp
    :members: