======================
salt.states.ini_manage
======================

.. automodule:: salt.states.ini_manage
    :members: