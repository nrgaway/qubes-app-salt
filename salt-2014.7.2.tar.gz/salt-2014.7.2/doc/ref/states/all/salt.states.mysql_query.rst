=======================
salt.states.mysql_query
=======================

.. automodule:: salt.states.mysql_query
    :members: