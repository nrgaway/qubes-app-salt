===================
salt.states.pkgrepo
===================

.. automodule:: salt.states.pkgrepo
    :members: