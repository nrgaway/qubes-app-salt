========================
salt.states.mongodb_user
========================

.. automodule:: salt.states.mongodb_user
    :members: