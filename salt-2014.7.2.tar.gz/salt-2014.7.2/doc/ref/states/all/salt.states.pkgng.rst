=================
salt.states.pkgng
=================

.. automodule:: salt.states.pkgng
    :members: