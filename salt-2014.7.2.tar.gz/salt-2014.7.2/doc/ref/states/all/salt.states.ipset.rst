=================
salt.states.ipset
=================

.. automodule:: salt.states.ipset
    :members: