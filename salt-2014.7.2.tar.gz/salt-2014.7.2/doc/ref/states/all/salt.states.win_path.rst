====================
salt.states.win_path
====================

.. automodule:: salt.states.win_path
    :members:
