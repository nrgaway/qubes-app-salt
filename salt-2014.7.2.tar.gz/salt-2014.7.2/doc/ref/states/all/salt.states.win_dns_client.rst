==========================
salt.states.win_dns_client
==========================

.. automodule:: salt.states.win_dns_client
    :members:
