===============
salt.states.rdp
===============

.. automodule:: salt.states.rdp
    :members: