==========================
salt.states.mysql_database
==========================

.. automodule:: salt.states.mysql_database
    :members: