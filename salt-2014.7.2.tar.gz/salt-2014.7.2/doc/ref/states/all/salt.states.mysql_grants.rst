========================
salt.states.mysql_grants
========================

.. automodule:: salt.states.mysql_grants
    :members: