======================
salt.states.mysql_user
======================

.. automodule:: salt.states.mysql_user
    :members: