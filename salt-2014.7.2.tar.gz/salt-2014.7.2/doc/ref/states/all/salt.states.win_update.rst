======================
salt.states.win_update
======================

.. automodule:: salt.states.win_update
    :members: