.. _global-state-arguments:

======================
Global State Arguments
======================

.. note::

    This documentation has been moved :ref:`here <requisites>`.
