.. _altering_states:

===============
Altering States
===============

.. note::

    This documentation has been moved :ref:`here <global-state-arguments>`.
