SaltTesting
===========

This project includes some if not all of the commonly required testing tools 
used in the several Salt Stack projects.
