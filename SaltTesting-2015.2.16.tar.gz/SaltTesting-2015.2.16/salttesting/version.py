# -*- coding: utf-8 -*-
'''
    salttesting.version
    ~~~~~~~~~~~~~~~~~~~

    :codeauthor: :email:`Pedro Algarvio (pedro@algarvio.me)`
    :copyright: © 2013-2015 by the SaltStack Team, see AUTHORS for more details.
    :license: Apache 2.0, see LICENSE for more details.
'''

__version_info__ = (2015, 2, 16)
__version__ = '.'.join(map(str, __version_info__))
